#!/system/bin/sh
# Magisk 卸载模块时调用: 停掉机器人并卸载容器挂载。
# 注意: 不删除 /data/qqbot（里面有 QQ 登录态和日志）；想彻底清干净，手动删 /data/qqbot 整个目录。
MODDIR=${0%/*}
[ -f "$MODDIR/files/stop_qqbot.sh" ] && /system/bin/sh "$MODDIR/files/stop_qqbot.sh" --inline >/dev/null 2>&1
exit 0

#!/system/bin/sh
# QQ机器人 Magisk 模块 —— 安装时检查（在 Magisk 安装器环境里运行）
# 只做检查和提示，不在这里下载大文件；真正的环境安装在首次开机后由 service.sh 后台完成。
# 注意: 绝不删除 /data/qqbot 里的任何东西——QQ 登录态、容器环境、云更新状态都在里面，
# 从旧版覆盖安装必须原样保留。

ui_print "********************************"
ui_print " QQ机器人（网盘搜索）模块 v1.2"
ui_print "********************************"

# 1) 架构检查：只支持 arm64
if [ "$ARCH" != "arm64" ]; then
  abort "! 本模块只支持 arm64 设备（当前: ${ARCH:-未知}），已取消安装"
fi
ui_print "- 架构检查通过: arm64"

# 2) /data 剩余空间检查：环境包下载+解压约需 3GB，QQ 数据还会增长，要求 ≥8GB
FREE_KB=$(df -k /data 2>/dev/null | tail -n 1 | awk '{print $4}')
case "$FREE_KB" in
  ''|*[!0-9]*) ui_print "- 警告: 读不到 /data 剩余空间，跳过空间检查";;
  *)
    FREE_GB=$((FREE_KB / 1048576))
    ui_print "- /data 剩余空间: ${FREE_GB}GB"
    if [ "$FREE_KB" -lt 8388608 ]; then
      abort "! /data 只剩 ${FREE_GB}GB，不足 8GB。先清理空间再装，否则环境下载会半途失败"
    fi
    ;;
esac

# 3) 建运行目录（数据都在 /data/qqbot，不动 /system；已存在的目录和数据原样保留）
mkdir -p /data/qqbot/logs /data/qqbot/dl /data/qqbot/bin /data/qqbot/shared /data/qqbot/backup /data/qqbot/run 2>/dev/null

# 4) 脚本权限
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm_recursive "$MODPATH/files" 0 0 0755 0755

ui_print "********************************"
ui_print " 安装完成，接下来请"
ui_print " 重启后模块会在后台自动："
ui_print " 1. 下载约 650MB 环境包（连好 WiFi 等它下完，约几分钟到十几分钟）"
ui_print " 2. 装好 Debian 容器 + NapCat + QQ + 机器人"
ui_print " 3. 自动启动机器人"
ui_print " 进度看: 内部存储/qqbot/status.txt 和 logs/install.log"
ui_print " 登录二维码会出现在: 内部存储/qqbot/qrcode.png"
ui_print " 用主力机上登着小号的 QQ 扫它，登录一次即可"
ui_print " 注意: 千万别在 QQ 里点，否则要重新扫码"
ui_print " --------------------------------"
ui_print " v1.2 起带模块控制台（WebUI）：在管理器的模块页点开本模块，"
ui_print " 就能看状态/日志、显示登录二维码、重启机器人、清除登录态，"
ui_print " 不用再进文件管理器翻日志了。"
ui_print " 云更新：机器人和脚本每 6 小时自动检查更新，"
ui_print " 群里主人发「更新」两个字也能立即检查，翻车会自动回滚；"
ui_print " 只有模块本体的大更新才需要你在管理器里点一下更新。"
ui_print "********************************"

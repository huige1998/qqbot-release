#!/system/bin/sh
# =====================================================================
# 云更新守护循环（updloop）—— 故意不进 OTA 更新集合:
# 它是负责"调用更新器"的最外层小循环，自身保持不变，这样即使某版
# updater.sh 出问题，下一版也能被它拉回来修好。
# 职责: 启动后先查一次；之后每 60 秒看一眼有没有 update.request
# （群里主人发了「更新」会由 bot.js 写这个文件）；每 6 小时定时查一次。
# 真正干活的是 updater.sh check，每次都新起一个子进程调用它，
# 所以 updater.sh 本体被 OTA 替换不会影响正在跑的循环。
# =====================================================================
DATA=/data/qqbot
BIN=$DATA/bin
SHARED=$DATA/shared

mkdir -p "$DATA/logs" "$DATA/run" "$SHARED" 2>/dev/null
exec >>"$DATA/logs/updater-daemon.log" 2>&1
echo "[$(date '+%Y-%m-%d %H:%M:%S')] updloop 启动 pid=$$"

INTERVAL=21600
last=0
while true; do
  now=$(date +%s)
  if [ -f "$SHARED/update.request" ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] 收到 update.request，触发检查"
    /system/bin/sh "$BIN/updater.sh" check
    last=$(date +%s)
  elif [ $((now - last)) -ge $INTERVAL ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] 定时检查"
    /system/bin/sh "$BIN/updater.sh" check
    last=$(date +%s)
  fi
  sleep 60
done

#!/system/bin/sh
# =====================================================================
# QQ机器人环境安装器（Magisk 模块首次开机时由 service.sh 后台拉起）
# 做什么: 下载 NapNeko 官方 NapCat-Termux 镜像（内含 Debian bookworm arm64
# 容器 + Linux QQ + NapCat），解压成 chroot 用的 rootfs，再装 Node 22、
# 写入机器人程序和 OneBot 配置。幂等 + 可断点续传：任何一步失败都会写
# 清楚日志，下次开机（或手动重跑本脚本）会从断点继续。只有全部完成才
# 写 /data/qqbot/.installed 标记。
# =====================================================================

MODDIR=${0%/*}
# 从模块目录运行时 MODDIR=.../files；允许手动指定模块根
case "$MODDIR" in */files) MODROOT=${MODDIR%/files} ;; *) MODROOT=/data/adb/modules/qqbot-magisk ;; esac
FILES=$MODROOT/files

DATA=/data/qqbot
ROOTFS=$DATA/rootfs
DL=$DATA/dl
LOGS=$DATA/logs
SD=/sdcard/qqbot
ACCOUNT=3322592972

ROOTFS_URL="https://github.com/NapNeko/NapCat-Termux/releases/download/v1.5.7/NapCat-Termux-v1.5.7.tar.gz"
ROOTFS_SIZE=649955388
ROOTFS_MEMBER="data/data/com.termux/files/home/bookworm-arm64"
NODE_URL="https://npmmirror.com/mirrors/node/v22.11.0/node-v22.11.0-linux-arm64.tar.gz"
NODE_URL2="https://nodejs.org/dist/v22.11.0/node-v22.11.0-linux-arm64.tar.gz"
NODE_SIZE=52689560

mkdir -p "$DATA" "$DL" "$LOGS" "$SD" 2>/dev/null

# ---- 单实例锁 -------------------------------------------------------
LOCK=$DATA/.install.lock
if ! mkdir "$LOCK" 2>/dev/null; then
  echo "install_env 已在运行，退出" >>"$LOGS/install.log"
  exit 0
fi
trap 'rmdir "$LOCK" 2>/dev/null' EXIT

log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOGS/install.log"
}
status() {
  # /sdcard 在开机早期可能还没挂好（mkdir 会静默失败），每次写状态前都补建目录，
  # 否则 status.txt 永远写不进去，用户侧看起来就像"没反应"（v1.1 真机实测的坑）
  mkdir -p "$SD" "$SD/logs" 2>/dev/null
  echo "$*" > "$SD/status.txt" 2>/dev/null
  log "状态: $*"
}
fail() {
  status "安装卡住了: $*（看 qqbot/logs/install.log；重启手机会自动重试续传）"
  exit 1
}

[ -f "$DATA/.installed" ] && { log "已安装过，跳过"; exit 0; }

# ---- 工具选择（安卓自带命令很精简，优先用 Magisk 的 busybox） --------
BB=""
[ -x /data/adb/magisk/busybox ] && BB=/data/adb/magisk/busybox

tarx() { # tarx <压缩包> <目标目录> [strip] [成员路径]
  if [ -n "$BB" ]; then
    if [ -n "$3" ]; then "$BB" tar -xzf "$1" -C "$2" --strip-components="$3" $4
    else "$BB" tar -xzf "$1" -C "$2"; fi
  else
    if [ -n "$3" ]; then tar -xzf "$1" -C "$2" --strip-components="$3" $4
    else tar -xzf "$1" -C "$2"; fi
  fi
}

# 文件大小（用 wc 而不是 stat：安卓 toybox 的 stat 格式不稳）
fsize() {
  s=$(wc -c < "$1" 2>/dev/null | tr -d ' \n')
  echo "${s:-0}"
}

# 断点续传下载: fetch <url> <outfile> <期望字节数> [备用url]
# 成功返回 0；下不完返回 1（已下载部分保留，下次续传）。
fetch() {
  url=$1; out=$2; want=$3; alt=${4:-}
  attempt=1
  while [ $attempt -le 8 ]; do
    cur=$(fsize "$out")
    [ "$cur" = "$want" ] && return 0
    if [ "$cur" -gt "$want" ]; then log "文件大小异常（$cur > $want），删掉重下"; rm -f "$out"; cur=0; fi
    log "下载 $(basename "$out"): 已有 ${cur}/${want} 字节，第 ${attempt} 次尝试"
    if command -v curl >/dev/null 2>&1; then
      curl -L -C - --connect-timeout 20 --retry 2 -o "$out" "$url" 2>>"$LOGS/install.log"
    elif [ -n "$BB" ]; then
      "$BB" wget -c -O "$out" "$url" 2>>"$LOGS/install.log"
    elif command -v wget >/dev/null 2>&1; then
      wget -c -O "$out" "$url" 2>>"$LOGS/install.log"
    else
      log "错误: 系统里找不到 curl/wget，无法下载"
      return 1
    fi
    cur=$(fsize "$out")
    if [ "$cur" != "$want" ] && [ -n "$alt" ]; then
      log "主线路没下完，换备用线路续传"
      url=$alt; alt=""
    fi
    attempt=$((attempt + 1))
    sleep 5
  done
  cur=$(fsize "$out")
  [ "$cur" = "$want" ]
}

# =====================================================================
status "正在下载机器人环境包（约650MB，请连WiFi耐心等）…"
fetch "$ROOTFS_URL" "$DL/rootfs.tar.gz" "$ROOTFS_SIZE" \
  || fail "环境包没下完（网络中断？）"

# =====================================================================
if [ ! -x "$ROOTFS/opt/QQ/qq" ] || [ ! -f "$ROOTFS/root/NapCat.linux.arm64/napcat.sh" ]; then
  status "环境包下载完成，正在解压（约1.6GB，需要几分钟）…"
  rm -rf "$ROOTFS"
  mkdir -p "$ROOTFS"
  # 镜像包里是 ZeroTermux 的备份结构，容器根在第 6 层目录，剥掉取根文件系统
  tarx "$DL/rootfs.tar.gz" "$ROOTFS" 6 "$ROOTFS_MEMBER" >>"$LOGS/install.log" 2>&1
  [ -x "$ROOTFS/opt/QQ/qq" ] || fail "解压后没找到 QQ 程序，环境包可能损坏（删掉 /data/qqbot/dl/rootfs.tar.gz 后重启可重下）"
  [ -f "$ROOTFS/root/NapCat.linux.arm64/napcat.sh" ] || fail "解压后没找到 NapCat，环境包结构和预期不一致"
  log "rootfs 解压完成"
else
  log "rootfs 已存在且完整，跳过解压"
fi

# DNS：chroot 里没有安卓的 DNS 服务，写公共解析（阿里/腾讯/谷歌）
printf 'nameserver 223.5.5.5\nnameserver 119.29.29.29\nnameserver 8.8.8.8\noptions timeout:3 attempts:2\n' > "$ROOTFS/etc/resolv.conf"
mkdir -p "$ROOTFS/sdcard" "$ROOTFS/root/qqbot"

# =====================================================================
if [ ! -x "$ROOTFS/usr/local/bin/node" ]; then
  status "正在安装 Node.js 运行环境…"
  fetch "$NODE_URL" "$DL/node.tar.gz" "$NODE_SIZE" "$NODE_URL2" \
    || fail "Node 安装包没下完（网络中断？）"
  tarx "$DL/node.tar.gz" "$ROOTFS/usr/local" 1 >>"$LOGS/install.log" 2>&1
  [ -x "$ROOTFS/usr/local/bin/node" ] || fail "Node 解压失败"
  log "Node 安装完成"
fi

# =====================================================================
status "正在写入机器人程序和配置…"
cp "$FILES/bot.js" "$ROOTFS/root/qqbot/bot.js" || fail "拷贝 bot.js 失败"

CFGDIR="$ROOTFS/root/NapCat.linux.arm64/config"
mkdir -p "$CFGDIR"
cp "$FILES/onebot11.json" "$CFGDIR/onebot11.json" || fail "写 OneBot 配置失败"
cp "$FILES/onebot11.json" "$CFGDIR/onebot11_$ACCOUNT.json"

# 容器内启动脚本（被 start_qqbot.sh 通过 chroot 调用）
cat > "$ROOTFS/root/qqbot/start-napcat.sh" <<EOF
#!/bin/bash
# NapCat 启动（容器内）: -q 为快速登录；没登录态时会自动出二维码
cd /root/NapCat.linux.arm64 || exit 1
exec ./napcat.sh -q $ACCOUNT >>/root/qqbot/napcat.log 2>&1
EOF

cat > "$ROOTFS/root/qqbot/start-bot.sh" <<'EOF'
#!/bin/bash
# 机器人看门狗（容器内）: bot.js 退出就 5 秒后重拉
while true; do
  /usr/local/bin/node /root/qqbot/bot.js >>/root/qqbot/bot.log 2>&1
  echo "[watchdog] bot.js 退出，5 秒后重启" >>/root/qqbot/bot.log
  sleep 5
done
EOF
chmod 755 "$ROOTFS/root/qqbot/start-napcat.sh" "$ROOTFS/root/qqbot/start-bot.sh"

# =====================================================================
# 写云更新的版本状态（更新器靠它判断当前版本）: 出厂版本来自模块 pkg_versions.txt。
# 这段只在首次安装走到（.installed 还不存在），不会覆盖升级路径写好的状态。
BV=$(grep '^BOT_VER=' "$FILES/pkg_versions.txt" 2>/dev/null | tail -n 1 | cut -d= -f2 | tr -d ' \r')
SV=$(grep '^SCRIPTS_VER=' "$FILES/pkg_versions.txt" 2>/dev/null | tail -n 1 | cut -d= -f2 | tr -d ' \r')
printf 'bot=%s\nscripts=%s\n' "${BV:-2}" "${SV:-2}" > "$DATA/versions.txt"

touch "$DATA/.installed"
status "环境安装完成，正在启动机器人…"
log "全部安装完成"
# 优先起 /data/qqbot/bin 里的运行时启动器（云更新维护的那份），没有再退回模块自带的
STARTSH="$FILES/start_qqbot.sh"
[ -f "$DATA/bin/start_qqbot.sh" ] && STARTSH="$DATA/bin/start_qqbot.sh"
nohup /system/bin/sh "$STARTSH" >>"$LOGS/service.log" 2>&1 &
exit 0

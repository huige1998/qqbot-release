#!/system/bin/sh
# QQ机器人 Magisk 模块 —— 开机服务（late_start service）
# 铁律: 必须立刻后台化并 exit 0，绝不阻塞开机流程；任何失败都只记日志。
# v1.1: 本脚本是不可变引导层（不参与云更新）。它只做一件事:
# 把运行时脚本从模块种到 /data/qqbot/bin/（首次、或模块 versionCode
# 比上次种下时更高时），然后拉起 bin/run.sh，后续全部归 run.sh 管。
# 平时不动 bin/，云更新的成果不会被开机冲掉。
MODDIR=${0%/*}
DATA=/data/qqbot
BIN=$DATA/bin

mkdir -p "$DATA/logs" "$BIN" "$DATA/shared" "$DATA/run" 2>/dev/null

MVC=$(grep '^versionCode=' "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2 | tr -d ' \r')
SVC=$(cat "$BIN/.seeded_vc" 2>/dev/null | tr -d ' \r')

seed_scripts() {
  for f in run.sh updloop.sh updater.sh start_qqbot.sh stop_qqbot.sh chroot_run.sh; do
    [ -f "$MODDIR/files/$f" ] && cp "$MODDIR/files/$f" "$BIN/$f"
  done
  chmod 755 "$BIN"/*.sh 2>/dev/null
  echo "${MVC:-0}" > "$BIN/.seeded_vc"
  # 刷了更高版本模块时，bin 里的脚本已换成模块自带的，把版本状态对齐，
  # 免得更新器又把同样的脚本"更新"一遍。bot.js 在 rootfs 里，不受影响。
  if [ -f "$DATA/versions.txt" ]; then
    SV=$(grep '^SCRIPTS_VER=' "$MODDIR/files/pkg_versions.txt" 2>/dev/null | tail -n 1 | cut -d= -f2 | tr -d ' \r')
    if [ -n "$SV" ]; then
      grep -v '^scripts=' "$DATA/versions.txt" > "$DATA/.versions.tmp" 2>/dev/null
      echo "scripts=$SV" >> "$DATA/.versions.tmp"
      mv "$DATA/.versions.tmp" "$DATA/versions.txt"
    fi
  fi
}

if [ ! -f "$BIN/run.sh" ] || [ "${MVC:-0}" -gt "${SVC:-0}" ]; then
  seed_scripts
fi

(
  # 等系统开机完成再动手，避免和开机流程抢资源
  i=0
  while [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ] && [ $i -lt 120 ]; do
    sleep 5
    i=$((i + 1))
  done
  sleep 10

  if [ -f "$BIN/run.sh" ]; then
    nohup /system/bin/sh "$BIN/run.sh" "$MODDIR" >>"$DATA/logs/service.log" 2>&1 &
  else
    # 兜底: 种脚本失败时退回 v1.0 的旧路径，保证机器人还能起
    echo "run.sh 缺失且种下失败，退回旧路径" >>"$DATA/logs/service.log"
    if [ -f "$DATA/.installed" ]; then
      nohup /system/bin/sh "$MODDIR/files/start_qqbot.sh" >>"$DATA/logs/service.log" 2>&1 &
    else
      nohup /system/bin/sh "$MODDIR/files/install_env.sh" >>"$DATA/logs/install-boot.log" 2>&1 &
    fi
  fi
) </dev/null >/dev/null 2>&1 &

exit 0
